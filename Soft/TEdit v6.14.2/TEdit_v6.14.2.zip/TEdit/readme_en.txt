TEDIT v6.7.1


ATTENTION! TEDIT IS INTENDED FOR ADVANCED USERS ONLY.
IF YOU DO NOT KNOW THE NEXT POINTS ...
  - ELEMENTARY STRUCTURE OF THE GAME
  - THE POSSIBILITIES AND LIMITATIONS OF THE GAME
  - WHAT IS "MOD"
  - WHAT IS THE "DEF", "DEFS OF CHASSIS/WHEELS/CARGOES" AND WHERE TO FIND THEM
  - WHAT IS THE SAVEGAME AND WHERE TO SEEK IT
... THEN YOU HAVE NOTHING TO DO IN TEDIT! DELETE TEDIT AND FORGET ABOUT IT!


INSTALL:

1. In main config.cfg of the game parameter g_save_format should be "2"!
2. Copy entire "TEDIT" folder somewhere on your computer.
3. Delete all old TEDIT tools, mods and plugins.
4. Copy new TEDIT tools, mods and plugins into their folders.


WORKING PRINCIPLE:
1. Do a savegame in the game.
2. Switch to the program, load (or reload) in the program this savegame.
3. Do your work in the program and then save the savegame.
4. Switch back to the game and load THE SAME savegame!


The Mods folder contains mods needed for fully work of the program:
- tedit_notebook_ats.scs - modified notebook for American Truck Simulator
- tedit_notebook_ets.scs - modified notebook for Euro Truck Simulator 2
- tedit_opengates_ats.scs - opened gates for ATS 1.6+
- tedit_opengates_ets.scs - opened gates for ETS2 1.27+
- tedit_system_font.scs - changed system font for console (for ATS and ETS2).
Place the necessary files into your "mod" folder.

ATTENTION! Since the DEFAULT trucks in the ATS do not have slots for "toys", 
you can not put a notebook in them. In this case, use either information on the map screen, 
or mods allowing you to put "toys" in the trucks, including a notebook.


The Plugins folder contains plugin needed for fully work of the program.
This plugin needs to interact with the program directly from the game.
The plugin is in two variants - for x86 and for x64.
Copy entire bin folder into the folder where game is installed:
...\Euro Truck Simulator 2\ or ...\American Truck Simulator\.   


The Tools folder contains tools to automatically create of files needed for TEDIT:
aliases files, dispatcher_cargoes.txt, special_cargoes.txt and tedit.ini files. 
See the details in readme files.

 
Most of help you can read in the program by pressing F1 key and moving mouse to any
elements of the program. You can also see some help videos from Videos folder.


DESCRIPTION OF V6.7.1:

This version supports multiply trailers (doubles, triples, etc.). How to build, load
and unload them - see in video "Multiply trailers - build, load, unload.mp4". When you
load a cargo into the trailer the mass of a cargo is distributed equally between trailer
and its dolly (parent trailer), but only if parent trailer have no jobs! 

Now each cargo have COG coefficients (cog.txt file). If program detects a missing cargo
COG then used COG (0, 0.4444, 0) by default. You can change COG for each cargo manually
in the program (in "Bases cargoes" dialog). 

Now in "Hotkeys config" dialog the codes of the keys represented as key names instead as 
numeric codes.

Now it is possible to cancel selected job by pressing [Delete] key in the job list.
Now take into account prices from trailers.txt file when you Sell a trailer.

The tools was updated.

 
DESCRIPTION OF V5.4.1:

In this new version you can copy "TEDIT" folder somewhere on your computer.
When you first start the program, the file game.sii will not be detected - press "Retry" button
and specify the path to the game.sii file.

The language settings will be reset to english. If it's needed, you can specify other aliases file
(see "aliases_filename=..." parameter in config.cfg file).

Now it is possible to add/remove any number of accessories of any type (paints, wheels, other accessories -
flags, beacons, plates, etc.). Also you can edit all parameters of selected accessory (double click on
accessory).


Best regards,
Alex (knox_xss)