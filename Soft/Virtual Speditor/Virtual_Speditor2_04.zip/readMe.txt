﻿For polish read czytajTo.txt
This program allows to change jobs in game. You are able to set origin and destination of cargo. Program changes existing jobs to ones we want. That gives limitation - we cannot add job for company, that don't have any job in it's job list.

Language should be detected according to your system settings. If not, you can overwrite setting by setting in program config.cfg file proper code. Codes are available at the end of readme.

Requirements:
- Visual C++ Redistributable 2012 (32 bit) You can download it from here: http://www.microsoft.com/en-us/download/details.aspx?id=30679

Preparing ETS:

Thanks to Sniper, you don't have to change g_save_format anymore. Program is using his SiiDecrypt tool to decode save from format 0.

*********
Optional:
You have to change one parameter in config.cfg in your EuroTruckSimulator2 directory. You need set
uset g_save_format "2"

ETS now will write save file in format, that decoder can read. This is one time change - you won't have to think of it anymore. If you changed save_format from other value, you have to resave your game in new format. To do that, please start your ETS->load profile, exit profile - autosave with new format will be created. (for the next use you just start my program).
It is important that your profile isn't loaded while starting program! That is because loaded profile will overwrite autosave in some time, so you will loose all the changes.
**********

Program is gathering data from your save file in order to have distances between cities. This database is not complete, however it will be filled when used. Pragram adds data everytime you load save. In error.log you can find out information of how many total records you have, and how many were added.
Due to new local DB, it has option to import/export data. In config cfg you have line: DB Mode:normal. Possible entries are DB Mode:import and DB Mode:export and DB Mode:clear
Export will create file containing database in program folder (Database1.txt). You can send this file to your friend, so he can import it back. Import will tak Database1.txt file, and put it into database. It will not duplicate records - only new records will be added. However, due to no duplicates, it needs to searched through all the database to search records - import may work slow (few minutes)! "Clear" mode will clear your database totaly, so speditor will have to learn everything from scratch.

manifest.txt file will be created in program folder every time we save file. This will contain data for added cargo. Bare in mind, that file will be overwritten everytime save is clicked, so if you need history, then you need to copy file to safe place.

Start program: Virtual_Speditor.exe
It is important that you have all files unpacked into one folder.

You can enter path to your profile in text box, or choose it pressing '...' button. It usually looks something similar to this:
MyDocuments\Euro Truck Simulator 2\profiles\[profile_directory]\save\autosave\
you can replace 'autosave' with any save you want!!

If you just prepared ETS as written above, correct profile directory will be the one with newest modification time!

Next, you press 'load' button - this will decode save, and load it to the program. This might take a while, depends of how advanced your profile is. There will be displayed profile name - this will allow you to confirm you choose correct save.
On the left we have origin City and company, on the right destination. Far to the right you have cargo. You cannot select trailer, as ETS jobs are defined for cargo. Your trailer will be selected automatic according to your cargo definitions in game (mods are accepted).
Add cargo using 'Add cargo' button. You are allowed to add more than one cargo. Limitation here is that you cannot add more than one cargo to one company. If you will do, program will overwrite earlier job, and leave only the last one. List of cargoes is limited to 7, but you can add more than that - they won't be displayed on the screen.
When you finish with adding cargo, press 'save file' button - this will OVERWRITE your save file you choose in game. However backup file is created (game.sii_backup) in the save directory.
 You can now close program, and load your ETS profile. Your added jobs will be visible in game. First cargo will have pickup time of 50h. Every next cargo will add additional 72h for that (second 144h etc.)

program has function to load cargoes from mods. There is example of cargo.fil (contains already existing cargoes). This is advanced tool to load cargoes outside of job marked in game. You have to know what are you doing - if you will enter names wrong, and add that cargo to the list, then most probably game will crash to desktop. If you don't understand what is it for, then better do not touch :)

loop option in config.cfg - you can loop your routes every Nth. If you enter loop:0 - no loop, loop:5 means, that every 5 routes speditor will send you home (starting city and company)

cargo File only - if you added cargo.fil and don't want to have original cargo in speditor - only added, set this option to 1.

You can filter destinations by companies now in interface - it works only for destination. It will display only cities containing selected company.

You can turn on/off excluding companies - when ticket, it only shows companies that are active, and have some cargoes assigned. If turned off, it will show all the cities that you have had in your save (so, if you turned mod off, and some cities disapeared, they will be visible). If on, it also filters off delivery only companies (the ones that can be delivered into, but cargoes cannot be picked up there). Adding job to/from that cities might cause instabilities in job market and eventually crash your game, or reset job market.

You can turn random generation of routes on and of in interface. When option is selected, speditor will randomly select new destination and cargo. If you don't want that, you can turn it off.

Country filtering - you can filter by country. It acctualy using dictionary file, to find out which city belong to which country. country_dict.csv file contains pairs of "city; country" - (ex. london;England). All countries you enter there, will appear in selection box. You will be able to filter by country. But, you can enter 'favourite' as a country, and you will be able to put there your favourite cities (Paris, London, Berlin for example). However, if city is entered more than once, program will take only the last record! It won't be added to both countries.
I've tried to add as much cities as I could there, but I don't know all maps and cities there. There are some empty ones at this moment, feel free to fill them up.
Additionally, program will add all missing cities to your country_dict.csv file. So, if you forget about Oslo in this file, it will be added at the end - without country and add information in error.log file about that. So, when your favourite map mod adds new cities, they will appear at the end of that file, and you can add them to country. You can add them to 'to_visit' list, or wherever you like :) It is fully customisable :)

Heavy Cargo - with Heavy Cargo Tractors there came a problem, with cargoes that weight more than 24t. They are treated as heavy, and need special heavy tracktor. Generaly, those cargoes should be now read from job market, you can add such a cargo to heavy_cargoes.csv file. Then, this cargo will be treated as heavy even if not found on the market.

Happy trucking!

language codes to set. Set instead of '0' following codes:
pl - Polski
ro - Română
en - English
de - Deutsche
it - Ialiano
es - Espaniol
fr - French
pt - Portugese
pt-BR -  Brasilian Portugese
ru - Russian
tr - Turkish
no - Norwegian
da - Danish
du - Dutch
el - Greek
fi - Finnish