DS-Font's TrueType Fonts
Font name: DS-Digital (Normal, Bold, Italic, Bold Italic), Version 1.0
Author: Dusit Supasawat
Web Site: http://ds-font.hypermart.net
Contact me: Dusit Supasawat, 325/38 Suksawat32 Ratburana Bangkok Thailand 10140
Email address: dusit@mailcity.com

Thanks for trying! We hope you really enjoy this my typeface. This font is 
distributed as shareware. You can use this font for a long time as you want. 
After all, when you think this font can be usefulness for you. You can send 
me some money, that would be way cool.

I'm only asking $20 US shareware fee per this typeface for personal use. 
And $45 US is the usual amount per this typeface for commercial use.

Distribution: You are free to distribute this archive so long as this text 
file is distributed with the archive, the font file have not been modified, 
and it is understood that the font's copyright remains with the original 
author (Dusit Supasawat).

To register send your payment to:

Dusit Supasawat
325/38 Suksawat32 Ratburana
Bangkok Thailand 10140

And fill out something as this order form, and send it in with your payment.

Font name:_________________________________________
Your information
Name:______________________________________________
Address:___________________________________________
City, State : _____________________________________
Zip Code:__________________________________________
Country:___________________________________________
E-MAIL address:____________________________________


You will receive fonts which you order by Email after registration. These fonts
will be generated for you by specify your name in font information.